<template>
  <div class="flex h-screen">
    <!-- Sidebar -->
    <aside
      class="w-20 md:w-56 bg-[#162238] text-white flex flex-col items-center md:items-start p-4 space-y-6"
    >
      <!-- Logo -->
      <div class="flex items-center space-x-2">
        <img src="../dmLogo.png" alt="Logo" class="w-10 h-10 rounded-full" />
        <span class="hidden md:block font-bold text-lg">Domore</span>
      </div>

      <!-- Navigation -->
      <nav class="flex flex-col space-y-4 w-full">
        <!-- The 'to' paths are updated to use the new nested structure -->
        <router-link
          to="/dashboard"
          class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded-md"
        >
          <span class="text-xl">🔲</span>
          <span class="hidden md:block">Dashboard</span>
        </router-link>
        <router-link
          to="/dashboard/planner"
          class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded-md"
        >
          <span class="text-xl">📄</span>
          <span class="hidden md:block">Planner</span>
        </router-link>
        <router-link
          to="/dashboard/schedule"
          class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded-md"
        >
          <span class="text-xl">📅</span>
          <span class="hidden md:block">Schedule</span>
        </router-link>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 relative p-6">
      <!-- This nested router-view will render Dashboard, Planner, or Schedule -->
      <router-view />
    </main>
  </div>
</template>

<script setup>
// No script logic needed for this component.
</script>