<!-- FOR NOW THIS IS THE HOMEPAGE, PERO ON FINAL STEPS I C-CONNECT LANG NIYA PAGES, AND SHOW THE HOMEPAGE FROM THE VIEWS FOLDER -->

<template>
  <div class="flex h-screen">
    <!-- Sidebar -->
    <aside
      class="w-20 md:w-56 bg-[#162238] text-white flex flex-col items-center md:items-start p-4 space-y-6"
    >
      <!-- Logo -->
      <div class="flex items-center space-x-2">
        <img src="./dmLogo.png" alt="Logo" class="w-10 h-10 rounded-full" />
        <span class="hidden md:block font-bold text-lg">Domore</span>
      </div>

      <!-- Navigation -->
      <nav class="flex flex-col space-y-4 w-full">
        <!-- Replaced <a> tags with <router-link> for navigation -->
        <router-link to="/" class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded-md">
          <span class="text-xl">🔲</span>
          <span class="hidden md:block">Dashboard</span>
        </router-link>
        <router-link
          to="/planner"
          class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded-md"
        >
          <span class="text-xl">📄</span>
          <span class="hidden md:block">Planner</span>
        </router-link>
        <router-link
          to="/schedule"
          class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded-md"
        >
          <span class="text-xl">📅</span>
          <span class="hidden md:block">Calendar</span>
        </router-link>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 relative p-6">
      <!-- The <router-view> component will render the content of the other routes here -->
      <router-view />
    </main>
  </div>
</template>

<script>
// No script changes are needed here, as the router is configured in main.js
export default {
  name: "App",
};
</script>