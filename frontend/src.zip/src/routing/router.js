import { createRouter, createWebHistory } from 'vue-router';
// import LandingPage from '../views/LandingPage.vue'; // Commented out to resolve file not found error
import MainLayout from '../views/mainlayout.vue';
import Dashboard from '../views/dashboard.vue';
import Planner from '../views/planner.vue';
import Schedule from '../views/schedule.vue';

const routes = [
  // Top-level route for the landing page without the sidebar
  // This route is commented out for now.
  // {
  //   path: '/',
  //   name: 'LandingPage',
  //   component: LandingPage
  // },

  // Main application routes, using MainLayout as the parent
  {
    path: '/', // The root path now directly shows the dashboard layout
    component: MainLayout,
    children: [
      { path: '', name: 'Dashboard', component: Dashboard },
      { path: 'planner', name: 'Planner', component: Planner },
      { path: 'schedule', name: 'Schedule', component: Schedule }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
